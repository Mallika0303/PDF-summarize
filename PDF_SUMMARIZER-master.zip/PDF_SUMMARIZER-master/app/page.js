// 'use-client'
import React from 'react'
import InputContainer from './Components/InputContainer'
const page = () => {
  return (
    <div>
      <InputContainer/>
    </div>
  )
}

export default page
